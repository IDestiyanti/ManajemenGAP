<?php
	include 'homepage/Header.php';

?>

    
    <section id="main-content">
    <section class="wrapper">

     <!--menu -->
     <div class="container">
              <div class="row">              
                <div class="col-lg-4">
                  <a href="bahanbaku" class="btn btn-outline-dark text-mid-center  buatan" role="button" style="padding:35px;font-size:25px;margin:30px">BAHAN BAKU</a> 
                </div>
               
                <div class="col-lg-4">
                  <a href="listrik" class="btn btn-info text-mid-center  buatan" role="button" style="padding:35px;font-size:25px;margin:30px">LISTRIK</a> 
                </div>
                <div class="col-lg-4">
                  <a href="keranjang" class="btn btn-info text-mid-center  buatan" role="button" style="padding:35px;font-size:25px;margin:30px">KERANJANG</a> 
                </div>

          </div>
    </section></section>
    
  <?php
	include 'homepage/Footer.php'
  ?>	