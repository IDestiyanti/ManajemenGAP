<?php
	include 'homepage/Header.php';

?>

      <!--main content start-->
      <section id="main-content">
    <section class="wrapper">
  <center><h1>STOK PRODUK</h1></center><br>
 
               <!-- tabel-->
     <center>
          <table class="table table-bordered table-hover" style="margin:10px;width:80%;background-color:white">
            <thead style="background-color:black">
            <tr>
            <th style="font-size:20px" scope="col">KODE PRODUK</th>
              <th style="font-size:20px" scope="col">MAMA PRODUK</th>
              <th style="font-size:20px" scope="col">JUMLAH STOK</th>
             
            </tr>
            </thead>
            <tbody>
              <tr>
             <?php
                
                $query = $this->db->query("SELECT id_barang,nama_barang,stok_barang FROM tb_barang");
                $row = $query->row_array();
                if(isset ($row)){
                    echo "<td>".$row['id_barang']."</td>";
                    echo "<td>".$row['nama_barang']."</td>";
                    echo "<td>".$row['stok_barang']."</td>";
                }
             ?>
     
              
              </tr>
            </tbody>
          </table>
            </center>
           
    </section></section>

  <?php
	include 'homepage/Footer.php'
  ?>	